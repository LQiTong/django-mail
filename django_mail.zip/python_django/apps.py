from django.apps import AppConfig


class PythonDjangoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'python_django'
